import java.util.ArrayList;



public class PPStateMinimax extends PPState {

	static final int maxCallDepth = 3;
	int bestSrcPos, bestDestPos;
	
	/**
	 * getName - get the name of the player
	 * @return the name of the player
	 */
	public String getName() {
		return "Neller_MINIMAX_EXP_DEPTH" + maxCallDepth;
	}
	
	/**
	 * getPlay - get the chosen play
	 * @param millisRemaining - player decision-making milliseconds remaining in the game. 
	 * @return an int array of length 3 containing the Amazon source position, Amazon destination position, and Amazon shot position.
	 * Each position is encoded in zero-based row-major form, i.e. for row r and column c on a SIZE-by-SIZE board, the position p is
	 * (r * SIZE + c).  For position p, r = p / SIZE; c = p % SIZE;
	 */
	public int[] getPlay(long millisRemaining) {
		if (!hasLegalMove()) {
			play[0] = play[1] = -1;
			return play;
		}
//		long startTime = System.currentTimeMillis();
//		long expMovesRemaining = ((SIZE * SIZE - 8) - turnsTaken) / 2;
//		long decisionMillis = millisRemaining / expMovesRemaining;
		//  Get move
		negamax(new PPState(this), maxCallDepth);
		play[0] = bestSrcPos;
		play[1] = bestDestPos;
		return play;
	}
	
	private double negamax(PPState state, int depthRemaining) {
		if (state.gameOver() || depthRemaining == 0)
			return state.simpleEval();
//		String prefix = "                                      ".substring(0,10-depthRemaining);
//		String player = (currentPlayer == SQUARE) ? "SQUARE" : "CIRCLE";
			state.computeLegalMoves();
			int numLegalMoves = state.legalMoveCount;
			int[] srcPositions = state.legalMoves[0].clone();
			int[] destPositions = state.legalMoves[1].clone();
			double qBest = Double.NEGATIVE_INFINITY;
			int bestMove = 0;
			for (int i = 0; i < numLegalMoves; i++) {
				int srcPos = srcPositions[i];
				int destPos = destPositions[i];
				state.makeMove(srcPos, destPos);
				double q = -negamax(state, depthRemaining - 1);
//				System.out.printf("%s%s MOVE%s%f\n", prefix, player, (q > qBest) ? "*" : " ", q);
				if (q > qBest) {
					qBest = q;
					bestMove = i;
				}
//				if (depthRemaining == 2) {
//					System.out.printf("%d-%d(%d):%f\n", srcPos, destPos, this.bestShotPos, q);
//				}
				state.unmakeMove(srcPos, destPos);
			}
			bestSrcPos = srcPositions[bestMove];
			bestDestPos = destPositions[bestMove];
//			System.out.printf("%sMAX: %f\n", prefix, qBest);
			return qBest;
		
	}

	
	public static void main(String[] args) {
		// Minimax game demo:
		PPStateMinimax state = new PPStateMinimax();	
		long gameMillis = 1000000;
		long startMillis = System.currentTimeMillis();
		state.init(0);
		int[] play = null;
		while (!state.gameOver()) {
			ArrayList<Integer> highlights = new ArrayList<Integer>();
			if (play != null) {
				if (play[0] >= 0)
					highlights.add(play[0]);
				highlights.add(play[1]);
			}
			PPView.exportSVG("PPFig" + state.turnsTaken, state, highlights);
			
			System.out.println(state.boardToString());
			play = state.getPlay((gameMillis - (System.currentTimeMillis() - startMillis)) / 2);
			System.out.println(state.moveToString(play[0], play[1]));
			System.out.println();
			state.makeMove(play[0], play[1]);
		}
		System.out.println(state.boardToString());
		if (state.getWinner() == 0)
			System.out.println("Draw.");
		else
			System.out.printf("%s wins.", state.getWinner() == SQUARE ? SQUARE_CHAR : CIRCLE_CHAR);
		ArrayList<Integer> highlights = new ArrayList<Integer>();
		if (play != null) {
			if (play[0] >= 0)
				highlights.add(play[0]);
			highlights.add(play[1]);
		}
		PPView.exportSVG("PPFigEnd", state, highlights);
	}
	
}
